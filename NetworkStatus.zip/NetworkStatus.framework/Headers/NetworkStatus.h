//
//  NetworkStatus.h
//  NetworkStatus
//
//  Created by NooN on 2/11/22.
//

#import <Foundation/Foundation.h>

//! Project version number for NetworkStatus.
FOUNDATION_EXPORT double NetworkStatusVersionNumber;

//! Project version string for NetworkStatus.
FOUNDATION_EXPORT const unsigned char NetworkStatusVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NetworkStatus/PublicHeader.h>
#import <NetworkStatus/NetMonitor.h>


